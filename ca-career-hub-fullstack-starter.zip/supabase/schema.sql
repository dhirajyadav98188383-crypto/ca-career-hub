-- CA Career Hub schema — run in Supabase SQL Editor.
-- Authenticated user data is isolated with Row Level Security (RLS).

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  daily_target_hours integer not null default 10 check (daily_target_hours between 1 and 16),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.study_tasks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 120),
  subject text not null check (subject in ('Accounting','Business & Finance','Law & Taxation','Assurance & IT')),
  is_done boolean not null default false,
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.routine_items (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  time text not null check (time ~ '^(?:[01][0-9]|2[0-3]):[0-5][0-9]$'),
  activity text not null check (char_length(activity) between 1 and 140),
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.finance_news (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  summary text,
  url text not null unique,
  source text,
  category text,
  published_at timestamptz,
  created_at timestamptz not null default now()
);

create index if not exists study_tasks_user_sort_idx on public.study_tasks(user_id, sort_order);
create index if not exists routine_items_user_sort_idx on public.routine_items(user_id, sort_order);
create index if not exists finance_news_published_idx on public.finance_news(published_at desc);

alter table public.profiles enable row level security;
alter table public.study_tasks enable row level security;
alter table public.routine_items enable row level security;
alter table public.finance_news enable row level security;

drop policy if exists "Users can read their profile" on public.profiles;
create policy "Users can read their profile" on public.profiles for select to authenticated using (auth.uid() = id);
drop policy if exists "Users can insert their profile" on public.profiles;
create policy "Users can insert their profile" on public.profiles for insert to authenticated with check (auth.uid() = id);
drop policy if exists "Users can update their profile" on public.profiles;
create policy "Users can update their profile" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

drop policy if exists "Users manage own tasks" on public.study_tasks;
create policy "Users manage own tasks" on public.study_tasks for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "Users manage own routine" on public.routine_items;
create policy "Users manage own routine" on public.routine_items for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "Authenticated users read news" on public.finance_news;
create policy "Authenticated users read news" on public.finance_news for select to authenticated using (true);

-- Automatically create a profile row for new auth users.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = ''
as $$
begin
  insert into public.profiles (id, email)
  values (new.id, new.email)
  on conflict (id) do update set email = excluded.email;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();
