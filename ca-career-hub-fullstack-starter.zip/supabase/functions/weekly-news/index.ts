// Supabase Edge Function: weekly finance news importer.
// Uses Google News RSS search feeds as discovery, stores article links for signed-in users.
// Treat each story as a lead and verify consequential claims at the original publisher.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-cron-secret",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const queries = [
  { q: "ICAN Nepal chartered accountant exam", category: "NEPAL · CA" },
  { q: "Nepal Rastra Bank banking finance economy", category: "NEPAL · BANKING" },
  { q: "IFRS accounting standards financial reporting", category: "GLOBAL · ACCOUNTING" },
  { q: "Nepal tax VAT budget finance", category: "NEPAL · TAX" },
];
function xmlText(xml: string, tag: string): string {
  const m = xml.match(new RegExp(`<${tag}(?:\\s[^>]*)?>([\\s\\S]*?)<\\/${tag}>`, "i"));
  return (m?.[1] || "").replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1")
    .replace(/<[^>]*>/g, "").replace(/&amp;/g, "&").replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'").replace(/&lt;/g, "<").replace(/&gt;/g, ">").trim();
}
function safeUrl(s: string) {
  try { const u = new URL(s); return ["http:", "https:"].includes(u.protocol) ? u.toString() : null; }
  catch { return null; }
}
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return new Response(JSON.stringify({ error: "Use POST" }), { status: 405, headers: { ...cors, "Content-Type": "application/json" } });

  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const cronSecret = Deno.env.get("NEWS_CRON_SECRET");
  if (!serviceKey || !supabaseUrl) return new Response(JSON.stringify({ error: "Server configuration missing" }), { status: 500, headers: { ...cors, "Content-Type": "application/json" } });

  // Scheduled calls must include a secret. Manual calls must be authenticated.
  const cronCall = !!cronSecret && req.headers.get("x-cron-secret") === cronSecret;
  if (!cronCall) {
    const auth = req.headers.get("Authorization");
    if (!auth) return new Response(JSON.stringify({ error: "Authentication required" }), { status: 401, headers: { ...cors, "Content-Type": "application/json" } });
    const client = createClient(supabaseUrl, serviceKey);
    const { data, error } = await client.auth.getUser(auth.replace(/^Bearer\s+/i, ""));
    if (error || !data.user) return new Response(JSON.stringify({ error: "Invalid session" }), { status: 401, headers: { ...cors, "Content-Type": "application/json" } });
  }

  const admin = createClient(supabaseUrl, serviceKey);
  const cutoff = new Date(Date.now() - 14 * 24 * 60 * 60 * 1000);
  const collected: Array<Record<string, unknown>> = [];
  for (const query of queries) {
    const rssUrl = `https://news.google.com/rss/search?q=${encodeURIComponent(query.q)}+when%3A14d&hl=en-NP&gl=NP&ceid=NP%3Aen`;
    try {
      const response = await fetch(rssUrl, { headers: { "User-Agent": "CA-Career-Hub/1.0 (weekly finance briefing)" } });
      if (!response.ok) continue;
      const xml = await response.text();
      const items = [...xml.matchAll(/<item>([\s\S]*?)<\/item>/gi)].slice(0, 8);
      for (const match of items) {
        const item = match[1];
        const title = xmlText(item, "title");
        const rawUrl = xmlText(item, "link");
        const url = safeUrl(rawUrl);
        const pubDate = xmlText(item, "pubDate");
        const published = pubDate ? new Date(pubDate) : new Date();
        if (!title || !url || Number.isNaN(published.getTime()) || published < cutoff) continue;
        const source = xmlText(item, "source") || "Google News result";
        collected.push({ title: title.slice(0, 300), summary: null, url, source: source.slice(0, 160), category: query.category, published_at: published.toISOString() });
      }
    } catch (e) { console.error("RSS fetch failed", query.category, e); }
  }

  const unique = [...new Map(collected.map(item => [item.url, item])).values()];
  if (!unique.length) return new Response(JSON.stringify({ ok: true, imported: 0, message: "No recent items found; try again later." }), { headers: { ...cors, "Content-Type": "application/json" } });
  const { error } = await admin.from("finance_news").upsert(unique, { onConflict: "url", ignoreDuplicates: false });
  if (error) {
    console.error(error);
    return new Response(JSON.stringify({ error: "Could not save news" }), { status: 500, headers: { ...cors, "Content-Type": "application/json" } });
  }
  return new Response(JSON.stringify({ ok: true, imported: unique.length, message: `Updated ${unique.length} news links.` }), { headers: { ...cors, "Content-Type": "application/json" } });
});