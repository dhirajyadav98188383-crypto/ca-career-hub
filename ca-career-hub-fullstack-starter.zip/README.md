# CA Career Hub — full-stack starter

A responsive React/Vite app with Supabase email/password authentication, cloud-saved study tasks, editable daily routine, daily target, and a weekly finance-news importer.

## Important deployment note

This is a deployable starter, not a website that has already been published. To enable real accounts and cloud persistence, you must connect your own Supabase project and deploy the frontend. Weekly news refresh needs the GitHub Actions secrets described below. Do not share service-role keys.

## 1. Requirements

- Node.js 20+
- A Supabase account/project
- A GitHub repository for the weekly scheduled news workflow (optional but recommended)
- A hosting provider such as Vercel or Netlify

## 2. Configure Supabase

1. Create a project at https://supabase.com/.
2. Open **SQL Editor** and run all of `supabase/schema.sql`.
3. Open **Project Settings → API** and copy the Project URL and publishable/anon key.
4. Copy `.env.example` to `.env.local` and fill in:

   ```env
   VITE_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
   VITE_SUPABASE_ANON_KEY=YOUR_PUBLISHABLE_OR_ANON_KEY
   ```

5. In Supabase **Authentication → URL Configuration**, set your local Site URL to `http://localhost:5173`. Later, add the production website URL and redirect URLs.
6. Configure email confirmation and SMTP according to your needs. For public production signups, configure a trusted SMTP provider and rate limits.

## 3. Run locally

```bash
npm install
npm run dev
```

Open the local URL printed by Vite. Sign up with your email and a unique password. The app stores study tasks, routine entries and study target in Supabase. RLS policies isolate user-owned rows.

To test a production build:

```bash
npm run build
npm run preview
```

## 4. Deploy the news function

Install the Supabase CLI, log in and link your project:

```bash
supabase login
supabase link --project-ref YOUR_PROJECT_REF
supabase functions deploy weekly-news
```

Set the function's server-side environment variables. The service-role key must remain server-side:

```bash
supabase secrets set NEWS_CRON_SECRET="USE_A_LONG_RANDOM_SECRET"
```

`SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` are normally available to Supabase Edge Functions. Never put `SUPABASE_SERVICE_ROLE_KEY` into a `VITE_` variable or browser code.

The function imports recent article links discovered through Google News RSS queries about ICAN, Nepal Rastra Bank, IFRS and Nepal tax. Google News is a discovery feed, not an official source; open the original publisher and verify important announcements. The frontend also links directly to official sources.

## 5. Schedule a Friday refresh

Push this project to GitHub. In **Settings → Secrets and variables → Actions**, create:

- `SUPABASE_FUNCTION_URL`: `https://YOUR_PROJECT_REF.supabase.co/functions/v1/weekly-news`
- `NEWS_CRON_SECRET`: the exact same value used in Supabase secrets

The workflow `.github/workflows/weekly-news.yml` runs Fridays at 02:15 UTC (08:00 Nepal time) and can also be run manually from the Actions tab. GitHub scheduled workflows can be delayed by GitHub; they are not guaranteed to run at the exact minute. Protect the repository and restrict who can edit workflows.

## 6. Deploy the frontend

Import the GitHub repository into Vercel or Netlify. Set the two `VITE_SUPABASE_*` environment variables in the hosting dashboard and deploy. The included `vercel.json` supports SPA routing. Add the final site URL to Supabase Auth's allowed redirect URLs.

## Security / production checklist

- Keep Supabase RLS enabled; never expose the service-role key.
- Use HTTPS and production auth redirect URLs.
- Configure SMTP, email confirmation, rate limits, backups and account recovery.
- Review auth policies and run security tests before opening public signups.
- The starter uses email/password auth and does not yet include social login, password reset UI, admin moderation or user analytics.
- The weekly feed is automated article discovery, not editorial fact-checking. Check the publisher for authoritative information.
- No database credentials or production URL are included in this package.

## Features

- Responsive luxury black-and-gold layout
- Sign-up / sign-in / sign-out
- Per-user study tasks with completion tracking
- Daily study-hour target
- Editable routine stored in the database
- Finance-news list and official source directory
- Weekly news ingestion function + GitHub Actions schedule
