import { useEffect, useMemo, useState } from 'react';
import { createClient } from '@supabase/supabase-js';
import {
  Activity, ArrowRight, BookOpen, CalendarDays, Check, CheckCircle2,
  ChevronRight, Clock3, ExternalLink, FileText, Landmark, LogOut,
  Menu, Newspaper, Plus, RefreshCw, ShieldCheck, Sparkles, Target, Trash2,
  X
} from 'lucide-react';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
const supabase = supabaseUrl && supabaseKey ? createClient(supabaseUrl, supabaseKey) : null;

const subjects = ['Accounting', 'Business & Finance', 'Law & Taxation', 'Assurance & IT'];
const sourceLinks = [
  { name: 'ICAN Nepal', label: 'CA profession & exam notices', url: 'https://www.ican.org.np/', tag: 'NEPAL · CA' },
  { name: 'Nepal Rastra Bank', label: 'Monetary policy & banking updates', url: 'https://www.nrb.org.np/', tag: 'NEPAL · BANKING' },
  { name: 'IFRS Foundation', label: 'International reporting standards', url: 'https://www.ifrs.org/news-and-events/', tag: 'GLOBAL · ACCOUNTING' },
  { name: 'ACCA Insights', label: 'Finance skills & career research', url: 'https://www.accaglobal.com/', tag: 'GLOBAL · CAREERS' },
  { name: 'SEBON Nepal', label: 'Capital market notices', url: 'https://www.sebon.gov.np/', tag: 'NEPAL · CAPITAL MARKETS' },
];

const initialTasks = subjects.map((subject, i) => ({
  id: `starter-${i + 1}`, title: `${subject}: complete one focused study session`,
  subject, is_done: false, sort_order: i
}));
const initialRoutine = [
  { time: '05:45', activity: 'Wake up and get ready' },
  { time: '06:30', activity: 'Institute / class and active note-taking' },
  { time: '12:00', activity: 'Return, lunch and a short rest' },
  { time: '14:00', activity: 'Accounting: concepts and practice' },
  { time: '16:00', activity: 'Business & Finance: focused study' },
  { time: '17:30', activity: 'Break, walk and refresh' },
  { time: '18:00', activity: 'Law & Taxation: reading and examples' },
  { time: '20:00', activity: 'Assurance & IT: revision and questions' },
  { time: '21:30', activity: 'Recall the day and plan tomorrow' },
  { time: '22:15', activity: 'Sleep and recover' },
];

function dateLabel() {
  return new Intl.DateTimeFormat('en-NP', { weekday: 'long', day: 'numeric', month: 'long' }).format(new Date());
}
function App() {
  const [session, setSession] = useState(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [configError, setConfigError] = useState(!supabase);
  const [authMode, setAuthMode] = useState('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [authMessage, setAuthMessage] = useState('');
  const [busy, setBusy] = useState(false);
  const [page, setPage] = useState('dashboard');
  const [mobileMenu, setMobileMenu] = useState(false);
  const [tasks, setTasks] = useState([]);
  const [routine, setRoutine] = useState([]);
  const [news, setNews] = useState([]);
  const [target, setTarget] = useState(10);
  const [newTask, setNewTask] = useState('');
  const [newSubject, setNewSubject] = useState(subjects[0]);
  const [routineEdit, setRoutineEdit] = useState(false);
  const [newsLoading, setNewsLoading] = useState(false);
  const [notice, setNotice] = useState('');

  useEffect(() => {
    if (!supabase) { setAuthLoading(false); return; }
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setAuthLoading(false);
    });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, s) => setSession(s));
    return () => listener.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (!session?.user) return;
    loadAll();
  }, [session?.user?.id]);

  async function loadAll() {
    const userId = session.user.id;
    const [taskRes, routineRes, profileRes, newsRes] = await Promise.all([
      supabase.from('study_tasks').select('*').eq('user_id', userId).order('sort_order'),
      supabase.from('routine_items').select('*').eq('user_id', userId).order('sort_order'),
      supabase.from('profiles').select('daily_target_hours').eq('id', userId).maybeSingle(),
      supabase.from('finance_news').select('*').order('published_at', { ascending: false }).limit(12),
    ]);
    if (taskRes.error) setNotice(taskRes.error.message);
    else if (taskRes.data.length) setTasks(taskRes.data);
    else {
      const seeds = initialTasks.map(({ title, subject, is_done, sort_order }) => ({
        user_id: userId, title, subject, is_done, sort_order
      }));
      const { data: created, error: seedError } = await supabase.from('study_tasks').insert(seeds).select();
      if (seedError) setNotice(seedError.message); else setTasks(created || []);
    }
    if (routineRes.error) setNotice(routineRes.error.message);
    else if (routineRes.data.length) setRoutine(routineRes.data);
    else {
      const seeds = initialRoutine.map((r, i) => ({ user_id: userId, ...r, sort_order: i }));
      const { data: created, error: seedError } = await supabase.from('routine_items').insert(seeds).select();
      if (seedError) setNotice(seedError.message); else setRoutine(created || []);
    }
    if (profileRes.data?.daily_target_hours) setTarget(profileRes.data.daily_target_hours);
    if (!newsRes.error) setNews(newsRes.data || []);
  }

  async function signIn(e) {
    e.preventDefault(); setBusy(true); setAuthMessage('');
    const action = authMode === 'signup'
      ? await supabase.auth.signUp({ email, password })
      : await supabase.auth.signInWithPassword({ email, password });
    setBusy(false);
    if (action.error) setAuthMessage(action.error.message);
    else if (authMode === 'signup' && !action.data.session) setAuthMessage('Account created. Check your email to confirm, then sign in.');
    else setAuthMessage('Welcome to CA Career Hub.');
  }

  async function signOut() { await supabase.auth.signOut(); setTasks([]); setRoutine([]); setNews([]); setPage('dashboard'); }
  async function ensureProfile() {
    if (!session?.user) return;
    await supabase.from('profiles').upsert({ id: session.user.id, email: session.user.email }, { onConflict: 'id', ignoreDuplicates: true });
  }
  async function addTask(e) {
    e.preventDefault();
    if (!newTask.trim()) return;
    const row = { user_id: session.user.id, title: newTask.trim(), subject: newSubject, is_done: false, sort_order: tasks.length };
    const { data, error } = await supabase.from('study_tasks').insert(row).select().single();
    if (error) return setNotice(error.message);
    setTasks(v => [...v, data]); setNewTask(''); setNotice('Study task added.');
  }
  async function toggleTask(task) {
    const next = !task.is_done;
    setTasks(v => v.map(t => t.id === task.id ? { ...t, is_done: next } : t));
    const { error } = await supabase.from('study_tasks').update({ is_done: next }).eq('id', task.id);
    if (error) { setNotice(error.message); setTasks(v => v.map(t => t.id === task.id ? { ...t, is_done: task.is_done } : t)); }
  }
  async function removeTask(id) {
    const { error } = await supabase.from('study_tasks').delete().eq('id', id);
    if (error) return setNotice(error.message);
    setTasks(v => v.filter(t => t.id !== id));
  }
  async function resetTasks() {
    const { error } = await supabase.from('study_tasks').update({ is_done: false }).eq('user_id', session.user.id);
    if (error) return setNotice(error.message);
    setTasks(v => v.map(t => ({ ...t, is_done: false })));
  }
  async function saveRoutine() {
    const valid = routine.every(r => /^\d{2}:\d{2}$/.test(r.time) && r.activity.trim());
    if (!valid) return setNotice('Enter a valid time and activity for every routine item.');
    const payload = routine.map((r, i) => ({
      user_id: session.user.id, time: r.time, activity: r.activity.trim(), sort_order: i
    }));
    const { error: deleteError } = await supabase.from('routine_items').delete().eq('user_id', session.user.id);
    if (deleteError) return setNotice(deleteError.message);
    const { data, error } = await supabase.from('routine_items').insert(payload).select();
    if (error) return setNotice(error.message);
    setRoutine(data.sort((a, b) => a.time.localeCompare(b.time))); setRoutineEdit(false); setNotice('Routine saved.');
  }
  async function saveTarget(value) {
    const n = Math.max(1, Math.min(16, Number(value) || 10)); setTarget(n);
    const { error } = await supabase.from('profiles').upsert({
      id: session.user.id, email: session.user.email, daily_target_hours: n
    }, { onConflict: 'id' });
    if (error) setNotice(error.message); else setNotice('Daily target saved.');
  }
  async function refreshNews() {
    setNewsLoading(true);
    const { data, error } = await supabase.functions.invoke('weekly-news');
    setNewsLoading(false);
    if (error) setNotice(`News refresh failed: ${error.message}`);
    else { setNotice(`News refresh requested. ${data?.message || ''}`); const { data: rows } = await supabase.from('finance_news').select('*').order('published_at', { ascending: false }).limit(12); setNews(rows || []); }
  }

  const done = tasks.filter(t => t.is_done).length;
  const percent = tasks.length ? Math.round(done / tasks.length * 100) : 0;
  const currentName = session?.user?.email?.split('@')[0] || 'CA student';
  const pageTitle = { dashboard: 'Your command centre', study: 'Study tracker', routine: 'Daily routine', news: 'Finance & professional news' }[page];

  if (authLoading) return <div className="loading-screen"><div className="brand-mark">C</div><p>Opening your study space…</p></div>;
  if (configError || !supabase) return <SetupScreen />;
  if (!session) return <AuthScreen {...{authMode,setAuthMode,email,setEmail,password,setPassword,authMessage,busy,signIn}} />;

  return <div className="app-shell">
    <aside className={`sidebar ${mobileMenu ? 'show' : ''}`}>
      <div className="brand"><div className="brand-mark">C</div><div><b>CA CAREER HUB</b><span>DISCIPLINE · GROWTH</span></div></div>
      <div className="nav-caption">WORKSPACE</div>
      <nav>{[
        ['dashboard', Activity, 'Dashboard'], ['study', BookOpen, 'Study tracker'],
        ['routine', CalendarDays, 'Daily routine'], ['news', Newspaper, 'Finance & news']
      ].map(([id, Icon, label]) => <button key={id} onClick={() => { setPage(id); setMobileMenu(false); }} className={`nav-item ${page === id ? 'active' : ''}`}><Icon size={17}/>{label}</button>)}</nav>
      <div className="north-star"><span className="eyebrow">YOUR NORTH STAR</span><p>Think like a CA.<br/><em>Lead like a CFO.</em></p><small>Small daily progress. Long-term excellence.</small></div>
      <button className="logout" onClick={signOut}><LogOut size={16}/> Sign out</button>
    </aside>
    <main className="main-area">
      <header className="topbar">
        <button className="mobile-menu-button" onClick={() => setMobileMenu(v => !v)} aria-label="Toggle menu"><Menu size={20}/></button>
        <div><div className="eyebrow">YOUR PERSONAL STUDY SPACE</div><p>{dateLabel()}</p></div>
        <div className="user-chip"><span className="avatar">{currentName.slice(0,1).toUpperCase()}</span><span>{currentName}</span></div>
      </header>
      {notice && <div className="notice" role="status">{notice}<button onClick={() => setNotice('')} aria-label="Dismiss"><X size={14}/></button></div>}
      {page === 'dashboard' && <section>
        <div className="hero"><div className="hero-copy"><div className="eyebrow"><Sparkles size={13}/> THE NEXT CHAPTER STARTS NOW</div><h1>Your ambition.<br/><em>Your discipline.</em><br/>Your future.</h1><p>Build your CA Foundation base with a clear plan, consistent practice, and confidence that grows every day.</p><button className="gold-button" onClick={() => setPage('study')}>Start studying <ArrowRight size={16}/></button></div><div className="hero-stamp"><span>CA</span><small>FOUNDATION<br/>TO LEADERSHIP</small></div></div>
        <div className="stats-grid">
          <Stat icon={CheckCircle2} label="TODAY'S COMPLETION" value={`${done} / ${tasks.length}`} note="Tasks completed" />
          <Stat icon={Target} label="STUDY PROGRESS" value={`${percent}%`} note="Of your listed tasks" />
          <div className="stat-card"><div className="stat-label"><Clock3 size={14}/> DAILY TARGET</div><div className="stat-value"><select aria-label="Daily study target" value={target} onChange={e => saveTarget(e.target.value)}>{Array.from({length:16},(_,i)=>i+1).map(n=><option key={n} value={n}>{n} hours</option>)}</select></div><div className="stat-note">Set a realistic target</div></div>
        </div>
        <div className="dashboard-grid">
          <div className="surface"><div className="section-head"><div><span className="eyebrow">STAY ON TRACK</span><h2>Today's priorities</h2></div><button className="text-button" onClick={() => setPage('study')}>All tasks <ChevronRight size={15}/></button></div><div className="task-list">{tasks.slice(0,5).map(t => <TaskRow key={t.id} task={t} onToggle={toggleTask} onDelete={removeTask}/>)}</div>{!tasks.length && <Empty text="Add your first study task in the Study Tracker."/>}</div>
          <div className="surface"><div className="section-head"><div><span className="eyebrow">PLAN YOUR DAY</span><h2>Next on your routine</h2></div><button className="icon-button" onClick={() => setPage('routine')}><ArrowRight size={16}/></button></div><div className="mini-routine">{routine.slice(0,5).map((r,i)=><div className="mini-routine-row" key={`${r.time}-${i}`}><time>{r.time}</time><span>{r.activity}</span></div>)}</div><button className="secondary-button full" onClick={() => setPage('routine')}>Manage routine</button></div>
        </div>
        <div className="surface source-strip"><div className="source-icon"><Landmark size={19}/></div><div><h3>Stay informed, think ahead.</h3><p>Official CA, accounting standards and banking sources — all in one place.</p></div><button className="secondary-button" onClick={() => setPage('news')}>Explore news <ArrowRight size={15}/></button></div>
      </section>}
      {page === 'study' && <section className="content-page"><PageIntro eyebrow="FOCUS MODE" title="Study tracker" subtitle="Turn each subject into small, measurable wins. Your changes are saved to your account."/><div className="stats-grid compact"><Stat icon={CheckCircle2} label="TASKS DONE" value={`${done} / ${tasks.length}`} note="Keep going" /><Stat icon={Target} label="COMPLETION" value={`${percent}%`} note="Current task list" /></div><div className="surface"><div className="section-head"><div><h2>Today's task list</h2><p className="subtext">Tick the box when you've finished the task.</p></div><button className="text-button" onClick={resetTasks}><RefreshCw size={14}/> Reset checks</button></div><div className="task-list">{tasks.map(t => <TaskRow key={t.id} task={t} onToggle={toggleTask} onDelete={removeTask}/>)}</div>{!tasks.length && <Empty text="No tasks yet. Add your first one below."/>}</div><div className="surface form-surface"><h2>Add a study task</h2><form className="add-task-form" onSubmit={addTask}><label>Task name<input required maxLength={120} value={newTask} onChange={e => setNewTask(e.target.value)} placeholder="e.g. Practise journal entries"/></label><label>Subject<select value={newSubject} onChange={e => setNewSubject(e.target.value)}>{subjects.map(s=><option key={s}>{s}</option>)}</select></label><button className="gold-button" type="submit"><Plus size={16}/> Add task</button></form></div></section>}
      {page === 'routine' && <section className="content-page"><PageIntro eyebrow="CONSISTENCY OVER INTENSITY" title="Daily routine" subtitle="Adapt this schedule to your real class times, travel, energy and responsibilities."/><div className="surface"><div className="section-head"><div><h2>Your day, planned</h2><p className="subtext">Times are shown in Nepal local time.</p></div><button className="secondary-button" onClick={() => setRoutineEdit(v => !v)}>{routineEdit ? <X size={15}/> : <FileText size={15}/>} {routineEdit ? 'Cancel editing' : 'Edit routine'}</button></div>{routineEdit ? <div className="routine-editor">{routine.map((r,i)=><div className="routine-edit-row" key={i}><input type="time" aria-label={`Time ${i+1}`} value={r.time} onChange={e=>setRoutine(v=>v.map((x,j)=>j===i?{...x,time:e.target.value}:x))}/><input aria-label={`Activity ${i+1}`} maxLength={140} value={r.activity} onChange={e=>setRoutine(v=>v.map((x,j)=>j===i?{...x,activity:e.target.value}:x))}/><button className="icon-button danger" onClick={()=>setRoutine(v=>v.filter((_,j)=>j!==i))} aria-label="Remove routine item"><Trash2 size={15}/></button></div>)}<div className="editor-actions"><button className="secondary-button" onClick={()=>setRoutine(v=>[...v,{time:'15:00',activity:'New study session'}])}><Plus size={15}/> Add time slot</button><button className="gold-button" onClick={saveRoutine}><Check size={16}/> Save routine</button></div></div> : <div className="routine-list">{[...routine].sort((a,b)=>a.time.localeCompare(b.time)).map((r,i)=><div className="routine-row" key={`${r.time}-${i}`}><time>{r.time}</time><div className="routine-dot"/><p>{r.activity}</p></div>)}</div>}</div><div className="surface tips-surface"><h2>Simple rules for effective study</h2><div className="tip-grid"><Tip n="01" title="Understand first" text="Learn the idea before trying to memorise it."/><Tip n="02" title="Practise on paper" text="Work through questions and show your steps."/><Tip n="03" title="Recall from memory" text="Close the book and explain what you learned."/><Tip n="04" title="Review mistakes" text="Revisit errors instead of only rereading notes."/></div></div></section>}
      {page === 'news' && <section className="content-page"><PageIntro eyebrow="KNOWLEDGE IS AN ADVANTAGE" title="Finance & professional news" subtitle="Use trustworthy sources for professional updates. Weekly articles appear here when the news job is configured and run."/><div className="news-toolbar"><div><span className="eyebrow">WEEKLY BRIEFING</span><p className="subtext">Article links include their original publishers.</p></div><button className="secondary-button" disabled={newsLoading} onClick={refreshNews}>{newsLoading?<span className="spinner"/>:<RefreshCw size={15}/>} Refresh news</button></div>{news.length ? <div className="news-grid">{news.map(item=><article className="news-card" key={item.id}><span className="eyebrow">{item.category || 'FINANCE UPDATE'}</span><h3><a href={item.url} target="_blank" rel="noreferrer">{item.title}<ExternalLink size={13}/></a></h3><p>{item.summary || 'Open the original source for the full update.'}</p><div className="news-meta"><span>{item.source || 'Source'}</span><span>{item.published_at ? new Date(item.published_at).toLocaleDateString() : 'Recent'}</span></div></article>)}</div> : <div className="empty-news"><Newspaper size={27}/><h3>Your weekly briefing will appear here</h3><p>Connect the weekly news function to populate articles. Until then, use these official sources.</p></div>}<div className="source-list">{sourceLinks.map(s=><article className="source-card" key={s.name}><div className="source-icon"><Landmark size={18}/></div><div className="source-copy"><span className="eyebrow">{s.tag}</span><h3>{s.name}</h3><p>{s.label}</p></div><a className="icon-button" href={s.url} target="_blank" rel="noreferrer" aria-label={`Open ${s.name}`}><ExternalLink size={16}/></a></article>)}</div><p className="disclaimer">News is informational, not financial advice. Verify exam, tax and regulatory updates on the original official website.</p></section>}
      <footer className="footer"><span>CA CAREER HUB</span><span>Discipline today. Leadership tomorrow.</span></footer>
    </main>
  </div>;
}

function Stat({icon: Icon, label, value, note}) { return <div className="stat-card"><div className="stat-label"><Icon size={14}/>{label}</div><div className="stat-value">{value}</div><div className="stat-note">{note}</div></div>; }
function TaskRow({task,onToggle,onDelete}) { return <div className={`task-row ${task.is_done?'done':''}`}><button className={`check-button ${task.is_done?'checked':''}`} onClick={()=>onToggle(task)} aria-label={task.is_done?'Mark incomplete':'Mark complete'}>{task.is_done&&<Check size={13}/>}</button><div className="task-copy"><span>{task.title}</span><small>{task.subject}</small></div><button className="delete-task" onClick={()=>onDelete(task.id)} aria-label="Delete task"><Trash2 size={14}/></button></div>; }
function PageIntro({eyebrow,title,subtitle}) { return <div className="page-intro"><span className="eyebrow">{eyebrow}</span><h1>{title}</h1><p>{subtitle}</p></div>; }
function Tip({n,title,text}) { return <div className="tip"><span>{n}</span><div><b>{title}</b><p>{text}</p></div></div>; }
function Empty({text}) { return <div className="empty-state">{text}</div>; }

function AuthScreen({authMode,setAuthMode,email,setEmail,password,setPassword,authMessage,busy,signIn}) {
  return <div className="auth-page"><div className="auth-decoration"><div className="brand"><div className="brand-mark">C</div><div><b>CA CAREER HUB</b><span>DISCIPLINE · GROWTH</span></div></div><div className="auth-quote"><span className="eyebrow">YOUR NEXT CHAPTER</span><h1>Build a career<br/>worth <em>working for.</em></h1><p>A calmer, clearer place to build your CA Foundation habits and long-term finance career.</p><div className="auth-points"><span><ShieldCheck size={16}/> Private account</span><span><CheckCircle2 size={16}/> Progress that saves</span><span><BookOpen size={16}/> Your study space</span></div></div><div className="auth-bottom">CA FOUNDATION · ACCOUNTING · FINANCE · LEADERSHIP</div></div><div className="auth-panel"><form className="auth-form" onSubmit={signIn}><span className="eyebrow">{authMode==='signup'?'START YOUR JOURNEY':'WELCOME BACK'}</span><h2>{authMode==='signup'?'Create your account':'Sign in to your hub'}</h2><p>{authMode==='signup'?'Set up your personal study dashboard.':'Your study plan is waiting for you.'}</p><label>Email address<input type="email" autoComplete="email" required value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com"/></label><label>Password<input type="password" minLength={8} autoComplete={authMode==='signup'?'new-password':'current-password'} required value={password} onChange={e=>setPassword(e.target.value)} placeholder="At least 8 characters"/></label>{authMessage&&<div className="auth-message" role="status">{authMessage}</div>}<button className="gold-button auth-submit" disabled={busy}>{busy?'Please wait…':authMode==='signup'?'Create account':'Sign in'} <ArrowRight size={16}/></button><div className="auth-switch">{authMode==='signup'?'Already have an account?':'New to CA Career Hub?'} <button type="button" onClick={()=>{setAuthMode(authMode==='signup'?'signin':'signup')}}>{authMode==='signup'?'Sign in':'Create account'}</button></div><small className="privacy-note">Your account and study data are stored in your configured Supabase project. Use a unique password.</small></form></div></div>;
}
function SetupScreen() {
  return <div className="setup-page"><div className="brand"><div className="brand-mark">C</div><div><b>CA CAREER HUB</b><span>DISCIPLINE · GROWTH</span></div></div><div className="setup-card"><span className="eyebrow">ONE-TIME SETUP</span><h1>Connect your private study space.</h1><p>The front-end is ready. Add a Supabase project to enable login, cloud-saved progress, routines, and the weekly news database.</p><ol><li>Create a project at <a href="https://supabase.com/" target="_blank" rel="noreferrer">Supabase.com</a>.</li><li>Run <code>supabase/schema.sql</code> in the SQL Editor.</li><li>Copy <code>.env.example</code> to <code>.env.local</code> and enter your project URL and publishable/anon key.</li><li>Restart the development server.</li></ol><div className="setup-warning"><ShieldCheck size={18}/><span>Never put a Supabase service-role key in browser code. The app uses Row Level Security for private user data.</span></div></div></div>;
}
